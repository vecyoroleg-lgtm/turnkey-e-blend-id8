'use strict';

// Mass balance adapted from TurnKey E Blend (see LICENSE-TurnKey.txt).
function mixToFull(input) {
    const { capacity, inTank, currentE, lowE, highE, targetE } = input;
    const isPercent = (n) => Number.isFinite(n) && n >= 0 && n <= 100;
    if (!Number.isFinite(capacity) || capacity <= 0 ||
        !Number.isFinite(inTank) || inTank < 0 || inTank > capacity ||
        (inTank > 0 && !isPercent(currentE)) ||
        ![lowE, highE, targetE].every(isPercent)) {
        return { kind: 'invalid' };
    }

    const remainingE = inTank === 0 ? 0 : currentE;
    const free = capacity - inTank;
    const ethanolInTank = inTank * remainingE;
    if (free < 1e-7) {
        return Math.abs(targetE - remainingE) < 1e-7
            ? { kind: 'full', achieved: remainingE }
            : { kind: 'unreachable', min: remainingE, max: remainingE };
    }
    if (lowE >= highE) {
        return { kind: 'fuel-order' };
    }

    const min = (ethanolInTank + free * lowE) / capacity;
    const max = (ethanolInTank + free * highE) / capacity;
    if (targetE < min - 1e-7 || targetE > max + 1e-7) {
        return { kind: 'unreachable', min, max };
    }

    const high = Math.max(0, Math.min(free, (capacity * targetE - ethanolInTank - free * lowE) / (highE - lowE)));
    const low = free - high;
    return { kind: 'mix', low, high, achieved: (ethanolInTank + low * lowE + high * highE) / capacity };
}

module.exports = { mixToFull };
