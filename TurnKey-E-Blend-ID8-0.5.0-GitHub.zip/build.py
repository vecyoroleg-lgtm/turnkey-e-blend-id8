"""Generate the ID8 resources, USB catalog, and GitHub source archive."""
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import xml.etree.ElementTree as ET
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
STORE = ROOT.parent / "mgu-store"
REFERENCE = STORE / "apps/robertn_store/robertn_store@0.9.15"
APP = ROOT / "app"
TREE = APP / "package"
RHMI = TREE / "rhmiData"
MANIFEST = json.loads((APP / "mgu-app.json").read_text(encoding="utf-8"))
APP_ID = MANIFEST["id"]
VERSION = MANIFEST["version"]
TITLE = "TurnKey E Blend"
DESCRIPTION = "Plan a petrol and E85 blend, read the remaining fuel from the car, or estimate tank ethanol."

PAGES = [
    ("blendHome", "homeTitle", "TurnKey E Blend", [
        ("button", "capacity", "Tank capacity"),
        ("button", "inTank", "Fuel in tank"),
        ("button", "readFuel", "Read fuel from car"),
        ("button", "finalVolume", "Fuel after refill"),
        ("button", "currentE", "Ethanol in tank"),
        ("button", "lowE", "Ethanol in petrol"),
        ("button", "highE", "Ethanol in E85"),
        ("button", "targetE", "Target ethanol"),
        ("button", "calculate", "Calculate"),
        ("button", "estimateTank", "Estimate tank ethanol"),
        ("button", "language", "Language · English"),
    ]),
    ("blendEdit", "editTitle", "Edit value", [
        ("label", "editValue", ""),
        ("button", "minusTen", "−10"),
        ("button", "minusOne", "−1"),
        ("button", "minusStep", "−0.1"),
        ("button", "plusStep", "+0.1"),
        ("button", "plusOne", "+1"),
        ("button", "plusTen", "+10"),
        ("button", "saveValue", "Save"),
        ("button", "useFullTank", "Use full tank"),
    ]),
    ("blendResult", "resultTitle", "Fuel to add", [
        ("label", "resultLine1", ""),
        ("label", "resultLine2", ""),
        ("label", "resultLine3", ""),
        ("button", "closeResult", "Back"),
    ]),
    ("blendEstimate", "estimateTitle", "Estimate tank ethanol", [
        ("button", "fuelBefore", "Fuel before refill"),
        ("button", "ethanolBefore", "Ethanol before refill"),
        ("button", "petrolAdded", "Petrol added"),
        ("button", "petrolE", "Ethanol in petrol"),
        ("button", "e85Added", "E85 added"),
        ("button", "e85E", "Ethanol in E85"),
        ("button", "estimateCalculate", "Calculate"),
        ("button", "estimateBack", "Back"),
    ]),
    ("blendLanguage", "languageTitle", "Language", [
        ("button", "languageEnglish", "English"),
        ("button", "languageUkrainian", "Українська"),
        ("button", "languageBack", "Back"),
    ]),
]


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def make_tile(path):
    width = height = 140
    rows = []
    for y in range(height):
        row = bytearray([0])
        for x in range(width):
            colour = (15, 21, 35, 255)
            if (36 <= x < 44 and 32 <= y < 101) or (
                36 <= x < 82 and (32 <= y < 40 or 93 <= y < 101)
            ) or (36 <= x < 73 and 62 <= y < 70):
                colour = (243, 247, 253, 255)
            if (88 <= x < 112 and 50 <= y < 85 and abs((x - 88) * 1.4 + y - 84) < 4) or (
                (x - 92) ** 2 + (y - 54) ** 2 <= 16 or (x - 109) ** 2 + (y - 82) ** 2 <= 16
            ):
                colour = (132, 202, 250, 255)
            if 106 <= y < 111 and 36 <= x < 112:
                colour = ((89, 190, 249, 255) if x < 61 else
                          (39, 103, 218, 255) if x < 86 else (245, 71, 82, 255))
            row.extend(colour)
        rows.append(row)

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(b"".join(rows)))
        + chunk(b"IEND", b"")
    )


def generate_rhmi():
    schema = "1.3.0"
    application = ET.Element("application")
    containers = {}
    for index, (page, title_name, title, items) in enumerate(PAGES, 1):
        state = ET.SubElement(application, "container", id=str(index), type="state", widget="LT_State_Wide_List")
        titlebar = ET.SubElement(state, "layoutGroup", id=str(100 + index * 2), name="Titlebar")
        group = ET.SubElement(state, "layoutGroup", id=str(101 + index * 2), name="List")
        ET.SubElement(group, "property", id="3", value="1")
        components = {}
        containers[str(index)] = {"type": "state", "name": page, "components": components}
        for offset, (kind, name, text) in enumerate([("title", title_name, title)] + items):
            node_id = str(index * 200 + offset)
            node = ET.SubElement(titlebar if kind == "title" else group, "component", id=node_id, type=kind)
            ET.SubElement(node, "property", id="2", value="1")
            properties = {"Visible": {"value": 1, "type": "UInt"}}
            row = {"Text": {"value": text, "type": "Text"}}
            if kind != "title":
                focusable = 3 if kind == "button" else 0
                ET.SubElement(node, "property", id="3", value=str(focusable))
                properties["Focusable"] = {"value": focusable, "type": "UInt"}
                node.set("widget", "LT_Button_MediaEntry_1Row" if kind == "button" else "LT_ScrollLabel")
            if kind == "button":
                row["PrimaryText"] = row.pop("Text")
                row["FrequencyText"] = {"value": "", "type": "Text"}
                row.update({key: {"value": False, "type": "Bool"} for key in
                            ["FrequencyVisible", "IconVisible", "ProgressVisible", "IsPlaying"]})
            components[node_id] = {"type": kind, "name": name, "properties": properties, "rows": [row]}

    ui = RHMI / "uiDescriptions/ID8"
    write_json(ui / "uiDescription.json", {"schemaVersion": schema, "containers": containers})
    ET.indent(application, space="    ")
    ET.ElementTree(application).write(ui / "application.xml", encoding="UTF-8", xml_declaration=True)
    write_json(RHMI / "application.json", {
        "schemaVersion": schema,
        "application": {
            "uuid": "a9fe9650-ceb1-483b-a5e2-6d29794a517f",
            "type": "OnlineApp", "name": APP_ID, "vendor": "owner", "version": VERSION,
            "defaultLanguage": "en_GB",
            "uiDescriptions": [{
                "applicationFilePath": "./uiDescriptions/ID8/application.xml",
                "uiDescriptionFilePath": "./uiDescriptions/ID8/uiDescription.json",
                "hmi": ["ID8"],
            }],
            "stringBundleUuid": "8d6ad332-305a-489d-815d-a75022965465",
            "resourceBundleUuid": "693ecc6b-76af-4c3c-a768-feae64349660",
            "variantGroups": [{
                "stringsPath": "./variantGroups/Common/texts",
                "resourcesPath": "./variantGroups/Common/images",
                "hmi": ["ID8"], "brands": ["BMW"],
            }],
            "entryPoints": [{
                "name": APP_ID, "uuid": "915434b7-f2bc-4ccc-9530-774456090bc6",
                "textId": "SID_TURNKEY_BLEND_TITLE", "icon": "turnkey.png",
                "insertionStateId": 20974, "insertionFocusId": 2, "insertionMode": "INSERT_BELOW",
                "insertionOrder": 0, "insertionPriority": 0, "previewType": "NONE",
                "bookmarkable": True, "private": None, "appearance": "DEFAULT",
                "isGroupHeader": False, "insertionGroup": 0,
            }],
        },
    })
    common = RHMI / "variantGroups/Common"
    write_json(common / "texts/en_GB.json", {"SID_TURNKEY_BLEND_TITLE": TITLE})
    make_tile(common / "images/turnkey.png")


def generate_package():
    package = json.loads((REFERENCE / "package.json").read_text(encoding="utf-8"))
    package.update(name=APP_ID, version=VERSION, description=DESCRIPTION, mguHmi=["ID8"],
                   files=["config", "rhmiData", "package.json", "npm-shrinkwrap.json", "permissions.json",
                          "javascript", "manifest.json", "LICENSE-GPL.txt", "LICENSE-TurnKey.txt",
                          "ATTRIBUTION.txt"])
    package["oapAppSettings"]["loggingId"] = "EBL8"
    write_json(TREE / "package.json", package)
    write_json(TREE / "npm-shrinkwrap.json", {
        "name": APP_ID, "version": VERSION, "lockfileVersion": 1,
        "requires": True, "dependencies": {},
    })
    manifest = json.loads((REFERENCE / "manifest.json").read_text(encoding="utf-8"))
    manifest["proxies"] = {name: entry for name, entry in manifest["proxies"].items()
                           if not any(part in name for part in (".controlelements.", ".hmicontext"))}
    manifest["proxies"]["de.bmw.infotainment.KombiIF"] = {
        "instances": "1",
        "attributes": {"statusRangeTankStatus": "r"},
    }
    write_json(TREE / "manifest.json", manifest)
    write_json(TREE / "config/base.json", {})
    shutil.copyfile(REFERENCE / "permissions.json", TREE / "permissions.json")
    shutil.copyfile(STORE / "LICENSE", TREE / "LICENSE-GPL.txt")
    (TREE / "ATTRIBUTION.txt").write_text(
        "TurnKey E Blend formula: Copyright (c) 2026 TurnKey Performance (MIT).\n"
        "https://github.com/HasMan/turnkey-ethanol-blend/tree/a378719e9c858ef4693949c3a7bca68bd5f9cafb\n"
        "ID8 RHMI patterns and app metadata based on MGU Store,\n"
        "Copyright (C) 2026 Robert Nisipeanu and IterioDev, GPL-3.0-or-later.\n"
        "https://github.com/robertnisipeanu/mgu-store/tree/7dffddd8c3d9efe171f790beb37aba36c41e062e\n",
        encoding="utf-8",
    )


def make_distribution():
    dist = ROOT / "dist"
    source = dist / "mgu-repo/turnkey-e-blend"
    source.mkdir(parents=True, exist_ok=True)
    archive = source / f"{APP_ID}@{VERSION}.tgz"
    subprocess.run([
        "node", "-e",
        "require(process.argv[1]).packSource(process.argv[2], process.argv[3])",
        str(STORE / "tools/oap_link.js"), str(APP), str(archive),
    ], check=True)
    data = archive.read_bytes()
    write_json(source / "catalog.json", {"schema": 2, "components": [{
        "id": APP_ID, "kind": "app", "title": TITLE, "description": DESCRIPTION,
        "version": VERSION, "mguHmi": ["ID8"], "build": "unit", "uninstallable": True,
        "requires": {"mgu-deploy": "0.7.0"},
        "artifact": {"name": archive.name, "size": len(data),
                     "sha256": hashlib.sha256(data).hexdigest(), "url": archive.name},
    }]})
    zip_path = dist / f"TurnKey-E-Blend-ID8-{VERSION}-USB.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as usb_zip:
        for item in (source / "catalog.json", archive):
            usb_zip.write(item, item.relative_to(dist))
    print(zip_path)

    repo_zip = dist / f"TurnKey-E-Blend-ID8-{VERSION}-GitHub.zip"
    with zipfile.ZipFile(repo_zip, "w", zipfile.ZIP_DEFLATED) as repo:
        paths = [ROOT / name for name in (".gitignore", "README.md", "build.py", "mgu-repo.json")]
        paths += [APP / "mgu-app.json"] + sorted((APP / "src").glob("*.js"))
        paths += sorted(item for item in TREE.rglob("*") if item.is_file())
        for item in paths:
            repo.write(item, item.relative_to(ROOT))
    print(repo_zip)


if __name__ == "__main__":
    generate_package()
    generate_rhmi()
    make_distribution()
