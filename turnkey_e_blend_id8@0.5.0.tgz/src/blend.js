'use strict';

const isPercent = (n) => Number.isFinite(n) && n >= 0 && n <= 100;

// Mass balance adapted from TurnKey E Blend (see LICENSE-TurnKey.txt).
function mixToVolume(input) {
    const { capacity, inTank, currentE, lowE, highE, targetE, finalVolume = capacity } = input;
    if (!Number.isFinite(capacity) || capacity <= 0 ||
        !Number.isFinite(inTank) || inTank < 0 || inTank > capacity ||
        (inTank > 0 && !isPercent(currentE)) ||
        ![lowE, highE, targetE].every(isPercent)) {
        return { kind: 'invalid' };
    }
    if (!Number.isFinite(finalVolume) || finalVolume <= 0) {
        return { kind: 'invalid-final-volume' };
    }
    if (finalVolume < inTank) return { kind: 'volume-below-fuel' };
    if (finalVolume > capacity) return { kind: 'volume-above-capacity' };

    const remainingE = inTank === 0 ? 0 : currentE;
    const free = finalVolume - inTank;
    const ethanolInTank = inTank * remainingE;
    if (free < 1e-7) {
        return Math.abs(targetE - remainingE) < 1e-7
            ? { kind: finalVolume === capacity ? 'full' : 'no-addition', achieved: remainingE }
            : { kind: 'unreachable', min: remainingE, max: remainingE };
    }
    if (lowE >= highE) {
        return { kind: 'fuel-order' };
    }

    const min = (ethanolInTank + free * lowE) / finalVolume;
    const max = (ethanolInTank + free * highE) / finalVolume;
    if (targetE < min - 1e-7 || targetE > max + 1e-7) {
        return { kind: 'unreachable', min, max };
    }

    const high = Math.max(0, Math.min(free, (finalVolume * targetE - ethanolInTank - free * lowE) / (highE - lowE)));
    const low = free - high;
    return { kind: 'mix', low, high, finalVolume, achieved: (ethanolInTank + low * lowE + high * highE) / finalVolume };
}

function estimateTankEthanol(input) {
    const { fuelBefore, ethanolBefore, petrolAdded = 0, petrolE, e85Added = 0, e85E } = input;
    const portions = [[fuelBefore, ethanolBefore], [petrolAdded, petrolE], [e85Added, e85E]];
    if (!portions.every(([litres]) => Number.isFinite(litres) && litres >= 0)) {
        return { kind: 'missing-volume' };
    }
    if (portions.some(([litres, percent]) => litres > 0 && !isPercent(percent))) {
        return { kind: 'missing-percentage' };
    }

    const totalLitres = fuelBefore + petrolAdded + e85Added;
    if (totalLitres === 0) return { kind: 'empty' };
    const ethanolLitres = portions.reduce((sum, [litres, percent]) =>
        litres === 0 ? sum : sum + litres * percent / 100, 0);
    return { kind: 'estimate', totalLitres, ethanolLitres, ethanolPercent: ethanolLitres * 100 / totalLitres };
}

module.exports = { mixToVolume, estimateTankEthanol };
