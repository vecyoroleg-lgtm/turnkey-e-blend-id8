'use strict';

const languageNames = { en: 'English', uk: 'Українська' };
const ukrainian = {
    'Language': 'Мова',
    'Tank capacity': 'Місткість бака',
    'Fuel in tank': 'Пальне в баку',
    'Fuel after refill': 'Пальне після заправки',
    'Ethanol in tank': 'Етанол у баку',
    'Ethanol in petrol': 'Етанол у бензині',
    'Ethanol in E85': 'Етанол в E85',
    'Target ethanol': 'Бажаний вміст етанолу',
    'Fuel before refill': 'Пальне до заправки',
    'Ethanol before refill': 'Етанол до заправки',
    'Petrol added': 'Долито бензину',
    'E85 added': 'Долито E85',
    'Enter value': 'Введіть значення',
    'Full tank': 'Повний бак',
    'Read fuel from car': 'Зчитати залишок з авто',
    'Reading fuel…': 'Зчитування залишку…',
    'Fuel unavailable · Retry': 'Залишок недоступний · Повторити',
    'Calculate': 'Розрахувати',
    'Estimate tank ethanol': 'Оцінити вміст етанолу',
    'Save': 'Зберегти',
    'Use full tank': 'До повного бака',
    'Back': 'Назад',
    'Fuel to add': 'Скільки долити',
    'Tank ethanol estimate': 'Оцінка вмісту етанолу',
    'Petrol: {amount}': 'Бензин: {amount}',
    'Blend: {ethanol} in {volume}': 'Суміш: {ethanol} у {volume}',
    'Tank already full. Target met.': 'Бак повний. Бажаний вміст досягнуто.',
    'Target met. No fuel to add.': 'Бажаний вміст досягнуто. Доливати не потрібно.',
    'Enter a final fuel volume above 0 L.': 'Введіть обсяг після заправки понад 0 л.',
    'Fuel after refill is below the current volume.': 'Бажаний обсяг менший за поточний залишок.',
    'Fuel after refill exceeds tank capacity.': 'Бажаний обсяг перевищує місткість бака.',
    'Target out of range.': 'Бажаний вміст недосяжний.',
    'Achievable range: {range}': 'Можливий діапазон: {range}',
    'E85 must have more ethanol than petrol.': 'Вміст етанолу в E85 має бути вищий, ніж у бензині.',
    'Check the fuel values.': 'Перевірте введені дані.',
    'Fuel in tank cannot exceed tank capacity.': 'Залишок не може перевищувати місткість бака.',
    'Estimated ethanol: {ethanol}': 'Орієнтовний вміст етанолу: {ethanol}',
    'Ethanol volume: {amount}': 'Обсяг етанолу: {amount}',
    'Total fuel: {amount}': 'Усього пального: {amount}',
    'The tank is empty.': 'Бак порожній.',
    'Enter the fuel volume before refilling.': 'Введіть обсяг пального до заправки.',
    'Enter ethanol % for each fuel volume above 0 L.': 'Введіть відсоток етанолу для кожного обсягу понад 0 л.',
    '−0.1': '−0,1',
    '+0.1': '+0,1',
};

function createLocale(code) {
    const useUkrainian = code === 'uk';
    function decimal(value, digits) {
        const formatted = value.toFixed(digits);
        return useUkrainian ? formatted.replace('.', ',') : formatted;
    }

    return {
        code: useUkrainian ? 'uk' : 'en',
        t(message, values = {}) {
            const template = (useUkrainian && ukrainian[message]) || message;
            return template.replace(/\{(\w+)\}/g, (_match, key) => String(values[key]));
        },
        decimal,
        litres(value, digits) {
            return decimal(value, digits) + (useUkrainian ? ' л' : ' L');
        },
        percent(value, digits) {
            return decimal(value, digits) + '%';
        },
    };
}

module.exports = { createLocale, languageNames };
