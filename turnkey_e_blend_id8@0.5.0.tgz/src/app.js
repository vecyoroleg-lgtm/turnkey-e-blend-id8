'use strict';

const fs = require('fs');
const path = require('path');
const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const logging = require('oap-sdk/src/logging/logging');
const someipBuilders = require('oap-sdk/src/someip/someipBuilders');
const { mixToVolume, estimateTankEthanol } = require('./blend.js');
const { createLocale, languageNames } = require('./i18n.js');

const log = logging.getSDKLogger();
const maxTankLitres = 200;
const readFuelLabel = 'Read fuel from car';
const languageFile = typeof __dirname === 'string'
    ? path.join(__dirname, '..', '..', 'data', 'turnkey-language') : null;
const pages = { home: 'blendHome', estimate: 'blendEstimate', edit: 'blendEdit', result: 'blendResult', language: 'blendLanguage' };
const actionLabels = {
    calculate: 'Calculate', estimateTank: 'Estimate tank ethanol', estimateCalculate: 'Calculate',
    estimateBack: 'Back', closeResult: 'Back', saveValue: 'Save', useFullTank: 'Use full tank',
    languageBack: 'Back', minusStep: '−0.1', plusStep: '+0.1',
};
const blendFields = [
    { key: 'capacity', label: 'Tank capacity', unit: 'L', min: 0.1, max: maxTankLitres, step: 0.1 },
    { key: 'inTank', label: 'Fuel in tank', unit: 'L', min: 0, max: maxTankLitres, step: 0.1 },
    { key: 'finalVolume', label: 'Fuel after refill', unit: 'L', min: 0, max: maxTankLitres, step: 0.1, emptyLabel: 'Full tank' },
    { key: 'currentE', label: 'Ethanol in tank', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'lowE', label: 'Ethanol in petrol', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'highE', label: 'Ethanol in E85', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'targetE', label: 'Target ethanol', unit: '%', min: 0, max: 100, step: 1 },
];
const estimateFields = [
    { key: 'fuelBefore', label: 'Fuel before refill', unit: 'L', min: 0, max: 200, step: 0.1 },
    { key: 'ethanolBefore', label: 'Ethanol before refill', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'petrolAdded', label: 'Petrol added', unit: 'L', min: 0, max: 200, step: 0.1, initial: 0 },
    { key: 'petrolE', label: 'Ethanol in petrol', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'e85Added', label: 'E85 added', unit: 'L', min: 0, max: 200, step: 0.1, initial: 0 },
    { key: 'e85E', label: 'Ethanol in E85', unit: '%', min: 0, max: 100, step: 1 },
];
const forms = { [pages.home]: blendFields, [pages.estimate]: estimateFields };
const adjust = [
    { name: 'minusTen', amount: -10 },
    { name: 'minusOne', amount: -1 },
    { name: 'minusStep', amount: -0.1 },
    { name: 'plusStep', amount: 0.1 },
    { name: 'plusOne', amount: 1 },
    { name: 'plusTen', amount: 10 },
];
const isTrue = (value) => value === true || value === 'true' || value === 1 || value === '1';
const displayValue = (field, value, locale) => value == null ? locale.t(field.emptyLabel || 'Enter value')
    : field.unit === 'L' ? locale.litres(value, 1) : locale.percent(value, 0);

function readLanguage() {
    if (!languageFile) return 'en';
    try {
        return fs.readFileSync(languageFile, 'utf8').trim();
    } catch (err) {
        if (err.code !== 'ENOENT') log.warn('Language setting: ' + err.message);
        return 'en';
    }
}

function rememberLanguage(code) {
    if (!languageFile) return;
    try {
        const temp = languageFile + '.tmp';
        fs.writeFileSync(temp, code + '\n', { mode: 0o600 });
        fs.renameSync(temp, languageFile);
    } catch (err) {
        log.warn('Could not save language: ' + err.message);
    }
}

async function readTankStatus(field) {
    let timer;
    try {
        const timeout = new Promise((resolve, reject) => {
            timer = setTimeout(() => reject(new Error('Tank reading timed out')), 3000);
        });
        return await Promise.race([field.getValue(), timeout]);
    } finally {
        clearTimeout(timer);
    }
}

function resultRows(result, { t, litres, percent, decimal }) {
    switch (result.kind) {
    case 'mix':
        return [t('Petrol: {amount}', { amount: litres(result.low, 2) }),
            'E85: ' + litres(result.high, 2),
            t('Blend: {ethanol} in {volume}', { ethanol: percent(result.achieved, 1), volume: litres(result.finalVolume, 1) })];
    case 'full':
        return [t('Tank already full. Target met.'), '', ''];
    case 'no-addition':
        return [t('Target met. No fuel to add.'), '', ''];
    case 'invalid-final-volume':
        return [t('Enter a final fuel volume above 0 L.'), '', ''];
    case 'volume-below-fuel':
        return [t('Fuel after refill is below the current volume.'), '', ''];
    case 'volume-above-capacity':
        return [t('Fuel after refill exceeds tank capacity.'), '', ''];
    case 'unreachable':
        return [t('Target out of range.'),
            t('Achievable range: {range}', { range: decimal(result.min, 1) + '–' + percent(result.max, 1) }), ''];
    case 'fuel-order':
        return [t('E85 must have more ethanol than petrol.'), '', ''];
    default:
        return [t('Check the fuel values.'), t('Fuel in tank cannot exceed tank capacity.'), ''];
    }
}

function estimateRows(result, { t, litres, percent }) {
    switch (result.kind) {
    case 'estimate':
        return [t('Estimated ethanol: {ethanol}', { ethanol: percent(result.ethanolPercent, 1) }),
            t('Ethanol volume: {amount}', { amount: litres(result.ethanolLitres, 2) }),
            t('Total fuel: {amount}', { amount: litres(result.totalLitres, 1) })];
    case 'empty':
        return [t('The tank is empty.'), '', ''];
    case 'missing-volume':
        return [t('Enter the fuel volume before refilling.'), '', ''];
    default:
        return [t('Enter ethanol % for each fuel volume above 0 L.'), '', ''];
    }
}

class BlendApp extends OnlineApp {
    constructor() {
        super();
        this.values = {};
        this.locale = createLocale(readLanguage());
        this.fuelLabel = readFuelLabel;
        this.actions = new Map();
        this.lastPress = new Map();
        this.page = pages.home;
        this.form = pages.home;
        this.queue = Promise.resolve();
        this.on('initialized', () => this.run(() => this.setup()));
        this.on('entryPointExecute', (uuid) => this.run(() => this.openEntry(uuid)));
        this.on('changeVisibility', (data) => {
            if (data && data.visible === false && this.ready) {
                this.run(() => this.reportVisible(false));
            }
        });
        this.on('shutdown', () => {
            Promise.resolve().then(() => this.destroyBundles())
                .catch((err) => log.warn(err.message)).then(() => process.exit(0));
        });
        this.on('error', (err) => log.warn(err.message));
    }

    run(action) {
        this.queue = this.queue.then(action).catch((err) => log.error(err.message));
        return this.queue;
    }

    component(name) {
        const item = this.rhmiApplication.getByName(name);
        if (!item) throw new Error('Missing RHMI element: ' + name);
        return item;
    }

    text(name, text, cell) {
        return this.component(name).setValue(0, cell || 'Text', text, 'Text');
    }

    bind(name, page, handler, singleFlight = false) {
        const item = this.component(name);
        const id = Number(item.getId());
        let pending = false;
        const activate = () => {
            const time = Date.now();
            if (this.page !== page || pending || time - (this.lastPress.get(id) || 0) < 160) return;
            this.lastPress.set(id, time);
            pending = singleFlight;
            this.run(async () => {
                try {
                    if (this.page === page) await handler();
                } finally {
                    pending = false;
                }
            });
        };
        this.actions.set(id, activate);
        item.on('action', activate);
    }

    async setup() {
        const rhmi = this.rhmiApplication;
        if (!rhmi) return this.initialized();
        Object.keys(forms).forEach((form) => {
            forms[form].forEach((field) => this.bind(field.key, form, () => this.openEditor(field, form)));
        });
        adjust.forEach(({ name, amount }) => this.bind(name, pages.edit, () => this.adjust(amount)));
        this.bind('saveValue', pages.edit, () => this.save());
        this.bind('useFullTank', pages.edit, () => this.useFullTank());
        this.bind('readFuel', pages.home, () => this.readFuelFromCar(), true);
        this.bind('calculate', pages.home, () => this.showResult(pages.home));
        this.bind('estimateTank', pages.home, () => this.openState(pages.estimate));
        this.bind('estimateCalculate', pages.estimate, () => this.showResult(pages.estimate));
        this.bind('estimateBack', pages.estimate, () => this.close(pages.estimate, pages.home));
        this.bind('closeResult', pages.result, () => this.close(pages.result, this.form));
        this.bind('language', pages.home, () => this.openState(pages.language));
        this.bind('languageEnglish', pages.language, () => this.selectLanguage('en'));
        this.bind('languageUkrainian', pages.language, () => this.selectLanguage('uk'));
        this.bind('languageBack', pages.language, () => this.close(pages.language, pages.home));
        rhmi.on('userEvent', (event) => {
            if (!event || event.eventType !== 'ACTION') return;
            const activate = this.actions.get(Number(event.sourceId));
            if (activate) activate();
        });
        const states = Object.values(pages).map((page) => {
            const state = this.component(page);
            state.on('focus', (event) => {
                if (event && isTrue(event.focus)) this.page = page;
            });
            return state;
        });
        rhmi.on('restoreHmi', () => this.run(() => this.renderLanguage()));
        await Promise.all(states.map((state) => state.updateResources()));
        const description = this.appDescription.application.entryPoints[0];
        const entry = this.getEntryPoints().find((point) => point.getDescription().uuid === description.uuid);
        if (!entry) throw new Error('TurnKey E Blend entry point is unavailable');
        await entry.init();
        await rhmi.mapEntryState(description.uuid, this.component(pages.home));
        this.entryUuid = description.uuid;
        try {
            await entry.entryPoint.setText(description.textId);
            await entry.entryPoint.setIcon(description.icon);
        } catch (err) {
            log.warn('Entry appearance: ' + err.message);
        }
        await entry.setAvailability('ENABLED');
        const visibility = this.getVisibilityData && this.getVisibilityData();
        const reason = (visibility && visibility.reason) || this.startReason;
        if (['ENTRY_POINT', 'LUM', 'BOOKMARK', 'TRIGGER_HMI'].includes(reason)) {
            await this.registerActive();
        }
        await this.initialized();
        await this.renderLanguage();
        this.ready = true;
        const last = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
        if (last) await this.openEntry(last);
    }

    async reportVisible(visible) {
        if (this.reportedVisible === visible) return;
        this.reportedVisible = visible;
        if (visible) {
            await this.registerActive();
            await this.registerHmiVisible();
        } else {
            await this.unregisterHmiVisible();
            await this.registerInactive();
        }
    }

    async openEntry(uuid) {
        if (!this.ready || uuid !== this.entryUuid) return;
        this.page = pages.home;
        await this.refresh();
        await this.rhmiApplication.openEntryState(uuid);
        await this.reportVisible(true);
    }

    async refresh() {
        const fields = blendFields.concat(estimateFields);
        await Promise.all(fields.map((field) => this.text(field.key,
            this.locale.t(field.label) + ' · ' + displayValue(field, this.fieldValue(field), this.locale), 'PrimaryText')));
        if (this.page === pages.edit && this.field) await this.renderEditor();
        if (this.page === pages.result) await this.renderResult();
    }

    async renderLanguage() {
        const { t, code } = this.locale;
        await Promise.all([
            ...Object.keys(actionLabels).map((name) => this.text(name, t(actionLabels[name]), 'PrimaryText')),
            this.text('language', t('Language') + ' · ' + languageNames[code], 'PrimaryText'),
            this.text('languageTitle', t('Language')),
            this.text('estimateTitle', t('Estimate tank ethanol')),
            this.text('readFuel', t(this.fuelLabel), 'PrimaryText'),
        ]);
        await this.refresh();
    }

    async selectLanguage(code) {
        this.locale = createLocale(code);
        rememberLanguage(this.locale.code);
        await this.renderLanguage();
        await this.close(pages.language, pages.home);
    }

    async readFuelFromCar() {
        this.fuelLabel = 'Reading fuel…';
        await this.text('readFuel', this.locale.t(this.fuelLabel), 'PrimaryText');
        let litres;
        try {
            if (!this.kombiProxy) {
                this.kombiProxy = await someipBuilders.buildAndInitTypedProxy(
                    'de.bmw.infotainment.KombiIF', '1', { timeoutMs: 5000 });
            }
            const status = await readTankStatus(this.kombiProxy.statusRangeTankStatus);
            litres = status && status.fluidLevelFuelTank;
            // The cluster uses 255 when the reading is unavailable.
            if (!Number.isFinite(litres) || litres < 0 || litres > maxTankLitres) {
                throw new Error('Invalid tank level');
            }
        } catch (err) {
            log.warn('Fuel reading unavailable: ' + (err && err.message || String(err)));
            this.fuelLabel = 'Fuel unavailable · Retry';
            await this.text('readFuel', this.locale.t(this.fuelLabel), 'PrimaryText');
            return;
        }

        this.values.inTank = Math.round(litres * 10) / 10;
        await this.refresh();
        this.fuelLabel = readFuelLabel;
        await this.text('readFuel', this.locale.t(this.fuelLabel), 'PrimaryText');
    }

    fieldValue(field) {
        return this.values[field.key] == null ? field.initial : this.values[field.key];
    }

    async openEditor(field, form) {
        this.form = form;
        this.field = field;
        const value = this.fieldValue(field);
        this.draft = value == null && field.key !== 'finalVolume' ? field.min : value;
        await this.renderEditor();
        await this.openState(pages.edit);
    }

    async renderEditor() {
        await Promise.all([
            this.text('editTitle', this.locale.t(this.field.label)),
            this.text('editValue', displayValue(this.field, this.draft, this.locale)),
            this.component('useFullTank').setProperty('Visible', this.field.key === 'finalVolume' ? 1 : 0, 'UInt'),
            ...['minusStep', 'plusStep'].map((name) =>
                this.component(name).setProperty('Visible', this.field.step === 0.1 ? 1 : 0, 'UInt')),
        ]);
    }

    async adjust(amount) {
        const field = this.field;
        if (!field || Math.abs(amount) < field.step) return;
        const usesCapacity = field.key === 'inTank' || field.key === 'finalVolume';
        const max = usesCapacity && this.values.capacity != null ? this.values.capacity : field.max;
        const start = this.draft == null ? (this.values.capacity || this.values.inTank || field.min) : this.draft;
        this.draft = Math.max(field.min, Math.min(max, Math.round((start + amount) * 10) / 10));
        await this.renderEditor();
    }

    async useFullTank() {
        if (!this.field || this.field.key !== 'finalVolume') return;
        this.draft = undefined;
        await this.save();
    }

    async save() {
        if (!this.field || this.page !== pages.edit) return;
        if (this.draft == null) delete this.values[this.field.key];
        else this.values[this.field.key] = this.draft;
        await this.close(pages.edit, this.form);
        await this.refresh();
    }

    async renderResult() {
        const estimating = this.form === pages.estimate;
        const rows = estimating ? estimateRows(estimateTankEthanol(this.values), this.locale) : resultRows(mixToVolume(this.values), this.locale);
        await this.text('resultTitle', this.locale.t(estimating ? 'Tank ethanol estimate' : 'Fuel to add'));
        await Promise.all(rows.map((text, index) => {
            const name = 'resultLine' + (index + 1);
            return Promise.resolve(this.text(name, text)).then(() =>
                this.component(name).setProperty('Visible', text ? 1 : 0, 'UInt'));
        }));
    }

    async showResult(form) {
        this.form = form;
        await this.renderResult();
        await this.openState(pages.result);
    }

    async openState(page) {
        await this.rhmiApplication.openState(page);
        this.page = page;
    }

    async close(page, returnPage) {
        await this.rhmiApplication.closeState(page);
        this.page = returnPage;
    }
}

const app = new BlendApp();
app.start().catch((err) => log.error('TurnKey E Blend: ' + err.message));
