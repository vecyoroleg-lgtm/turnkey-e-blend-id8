'use strict';

const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const logging = require('oap-sdk/src/logging/logging');
const { mixToFull } = require('./blend.js');

const log = logging.getSDKLogger();
const fields = [
    { key: 'capacity', label: 'Tank capacity', unit: 'L', min: 0.1, max: 200, step: 0.1 },
    { key: 'inTank', label: 'Fuel in tank', unit: 'L', min: 0, max: 200, step: 0.1 },
    { key: 'currentE', label: 'Ethanol in tank', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'lowE', label: 'Ethanol in petrol', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'highE', label: 'Ethanol in E85', unit: '%', min: 0, max: 100, step: 1 },
    { key: 'targetE', label: 'Target ethanol', unit: '%', min: 0, max: 100, step: 1 },
];
const adjust = [
    { name: 'minusTen', amount: -10 },
    { name: 'minusOne', amount: -1 },
    { name: 'minusStep', amount: -0.1 },
    { name: 'plusStep', amount: 0.1 },
    { name: 'plusOne', amount: 1 },
    { name: 'plusTen', amount: 10 },
];
const pages = { home: 'blendHome', edit: 'blendEdit', result: 'blendResult' };
const isTrue = (value) => value === true || value === 'true' || value === 1 || value === '1';
const displayValue = (field, value) => value == null ? 'Enter value'
    : field.unit === 'L' ? value.toFixed(1) + ' L' : value.toFixed(0) + '%';

function resultRows(result) {
    switch (result.kind) {
    case 'mix':
        return ['Petrol: ' + result.low.toFixed(2) + ' L',
            'E85: ' + result.high.toFixed(2) + ' L',
            'Expected ethanol: ' + result.achieved.toFixed(1) + '%'];
    case 'full':
        return ['Tank already full. Target met.', '', ''];
    case 'unreachable':
        return ['Target out of range.',
            'Achievable range: ' + result.min.toFixed(1) + '–' + result.max.toFixed(1) + '%', ''];
    case 'fuel-order':
        return ['E85 must have more ethanol than petrol.', '', ''];
    default:
        return ['Check the fuel values.', 'Fuel in tank cannot exceed tank capacity.', ''];
    }
}

class BlendApp extends OnlineApp {
    constructor() {
        super();
        this.values = {};
        this.actions = new Map();
        this.lastPress = new Map();
        this.page = pages.home;
        this.queue = Promise.resolve();
        this.on('initialized', () => this.run(() => this.setup()));
        this.on('entryPointExecute', (uuid) => this.run(() => this.openEntry(uuid)));
        this.on('changeVisibility', (data) => {
            if (data && data.visible === false && this.ready) {
                this.run(() => this.reportVisible(false));
            }
        });
        this.on('shutdown', () => {
            Promise.resolve().then(() => this.destroyBundles())
                .catch((err) => log.warn(err.message)).then(() => process.exit(0));
        });
        this.on('error', (err) => log.warn(err.message));
    }

    run(action) {
        this.queue = this.queue.then(action).catch((err) => log.error(err.message));
        return this.queue;
    }

    component(name) {
        const item = this.rhmiApplication.getByName(name);
        if (!item) throw new Error('Missing RHMI element: ' + name);
        return item;
    }

    text(name, text, cell) {
        return this.component(name).setValue(0, cell || 'Text', text, 'Text');
    }

    bind(name, page, handler) {
        const item = this.component(name);
        const id = Number(item.getId());
        const activate = () => {
            const time = Date.now();
            if (this.page !== page || time - (this.lastPress.get(id) || 0) < 160) return;
            this.lastPress.set(id, time);
            this.run(() => this.page === page ? handler() : undefined);
        };
        this.actions.set(id, activate);
        item.on('action', activate);
    }

    async setup() {
        const rhmi = this.rhmiApplication;
        if (!rhmi) return this.initialized();
        fields.forEach((field) => this.bind(field.key, pages.home, () => this.openEditor(field)));
        adjust.forEach(({ name, amount }) => this.bind(name, pages.edit, () => this.adjust(amount)));
        this.bind('saveValue', pages.edit, () => this.save());
        this.bind('calculate', pages.home, () => this.showResult());
        this.bind('closeResult', pages.result, () => this.close(pages.result));
        rhmi.on('userEvent', (event) => {
            if (!event || event.eventType !== 'ACTION') return;
            const activate = this.actions.get(Number(event.sourceId));
            if (activate) activate();
        });
        const states = Object.values(pages).map((page) => {
            const state = this.component(page);
            state.on('focus', (event) => {
                if (event && isTrue(event.focus)) this.page = page;
            });
            return state;
        });
        rhmi.on('restoreHmi', () => this.run(() => this.refresh()));
        await Promise.all(states.map((state) => state.updateResources()));
        const description = this.appDescription.application.entryPoints[0];
        const entry = this.getEntryPoints().find((point) => point.getDescription().uuid === description.uuid);
        if (!entry) throw new Error('TurnKey E Blend entry point is unavailable');
        await entry.init();
        await rhmi.mapEntryState(description.uuid, this.component(pages.home));
        this.entryUuid = description.uuid;
        try {
            await entry.entryPoint.setText(description.textId);
            await entry.entryPoint.setIcon(description.icon);
        } catch (err) {
            log.warn('Entry appearance: ' + err.message);
        }
        await entry.setAvailability('ENABLED');
        const visibility = this.getVisibilityData && this.getVisibilityData();
        const reason = (visibility && visibility.reason) || this.startReason;
        if (['ENTRY_POINT', 'LUM', 'BOOKMARK', 'TRIGGER_HMI'].includes(reason)) {
            await this.registerActive();
        }
        await this.initialized();
        await this.refresh();
        this.ready = true;
        const last = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
        if (last) await this.openEntry(last);
    }

    async reportVisible(visible) {
        if (this.reportedVisible === visible) return;
        this.reportedVisible = visible;
        if (visible) {
            await this.registerActive();
            await this.registerHmiVisible();
        } else {
            await this.unregisterHmiVisible();
            await this.registerInactive();
        }
    }

    async openEntry(uuid) {
        if (!this.ready || uuid !== this.entryUuid) return;
        this.page = pages.home;
        await this.refresh();
        await this.rhmiApplication.openEntryState(uuid);
        await this.reportVisible(true);
    }

    async refresh() {
        await Promise.all(fields.map((field) => this.text(field.key,
            field.label + ' · ' + displayValue(field, this.values[field.key]), 'PrimaryText')));
        if (this.page === pages.edit && this.field) await this.renderEditor();
        if (this.page === pages.result) await this.renderResult();
    }

    async openEditor(field) {
        this.field = field;
        this.draft = this.values[field.key] == null ? field.min : this.values[field.key];
        await this.renderEditor();
        await this.rhmiApplication.openState(pages.edit);
        this.page = pages.edit;
    }

    async renderEditor() {
        await Promise.all([
            this.text('editTitle', this.field.label),
            this.text('editValue', displayValue(this.field, this.draft)),
            ...['minusStep', 'plusStep'].map((name) =>
                this.component(name).setProperty('Visible', this.field.step === 0.1 ? 1 : 0, 'UInt')),
        ]);
    }

    async adjust(amount) {
        const field = this.field;
        if (!field || Math.abs(amount) < field.step) return;
        const max = field.key === 'inTank' && this.values.capacity != null ? this.values.capacity : field.max;
        this.draft = Math.max(field.min, Math.min(max, Math.round((this.draft + amount) * 10) / 10));
        await this.renderEditor();
    }

    async save() {
        if (!this.field || this.page !== pages.edit) return;
        this.values[this.field.key] = this.draft;
        await this.close(pages.edit);
        await this.refresh();
    }

    async renderResult() {
        const rows = resultRows(mixToFull(this.values));
        await Promise.all(rows.map((text, index) => {
            const name = 'resultLine' + (index + 1);
            return Promise.resolve(this.text(name, text)).then(() =>
                this.component(name).setProperty('Visible', text ? 1 : 0, 'UInt'));
        }));
    }

    async showResult() {
        await this.renderResult();
        await this.rhmiApplication.openState(pages.result);
        this.page = pages.result;
    }

    async close(page) {
        await this.rhmiApplication.closeState(page);
        this.page = pages.home;
    }
}

const app = new BlendApp();
app.start().catch((err) => log.error('TurnKey E Blend: ' + err.message));
